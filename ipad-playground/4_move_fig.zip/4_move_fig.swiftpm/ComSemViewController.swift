import SwiftUI

class ComSemViewController: ViewController {
    // 図形を動かす
    override func move(figure: UIView) {
        figure.center.x = figure.center.x + 1
        // figure.center.y = figure.center.y + 1
    }
}
