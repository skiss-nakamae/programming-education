import UIKit
// import PlaygroundSupport

class ViewController: UIViewController {
    
    var screenWidth: CGFloat = 0
    var screenHeight: CGFloat = 0
    
    // 四角のサイズ
    var figSize: CGFloat = 20.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //画面のサイズ
        screenWidth = self.view.bounds.width
        screenHeight = self.view.bounds.height - figSize
        
        //図形（正方形）生成
        let rect = UIView.init()
        //let rect = UIView.init(frame: //CGRect(x:0,y:0,width:10,height:10))
        let rectColor = UIColor.blue
        rect.backgroundColor = rectColor
        self.view.addSubview(rect)
        
        //初期位置を真ん中に
        rect.frame = CGRect(x: screenWidth/2, y: screenHeight/2, width: figSize, height: figSize)

        // タイマーで四角を動かす
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: {
            timer in
            // rect.center.x += 10
            self.move(figure: rect)
        })
        
    }
    
    func move(figure: UIView) {
        figure.center.x = figure.center.x + 1
    }
}

