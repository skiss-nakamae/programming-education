import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Button(action:{
                // action : 動作を書く
                speak("hello")
            }) {
                // テキストのボタン
                Text("hello")
            }
        }
    }
}
