import AVFoundation

// テキストを音声として再生するオブジェクト
let synthesizer: AVSpeechSynthesizer = AVSpeechSynthesizer()

/**
 引数で渡されたtext:Stringを音声出力する
 - parameter text: 音声出力するテキスト
 
  関数名(_ ラベル: 型)の書き方だとラベルを書かなくてもOKになる
 */
func speak(_ text: String) {
    let utterance = AVSpeechUtterance(string: text)
    utterance.voice = AVSpeechSynthesisVoice(language: "ja-JP")
    // ゆっくり話す
    // utterance.rate = AVSpeechUtteranceMinimumSpeechRate
    // 早口で話す
    // utterance.rate = AVSpeechUtteranceMaximumSpeechRate
    // ピッチ
    // utterance.pitchMultiplier = 0.5
    // ボリューム
    // utterance.volume = 1.0
    synthesizer.speak(utterance)
}
