import SwiftUI

class ComSemViewController: ViewController {
    // 速度
    var speed: CGPoint = CGPoint(x: 5.0 , y: 0.0 )
    
    // 速度を使って図形を動かす
    override func move(figure: UIView) {
        // 速度を使って位置を求める
        figure.center.x = figure.center.x + speed.x
        figure.center.y = figure.center.y + speed.y
        
        // 図形のx位置が画面から外に出たら
        if isXOnScreen(figure: figure) {
            speed.x = speed.x * -1.0
        }
        if isYOnScreen(figure: figure) {
            speed.y = speed.y * -1.0
        }  
    }
}
