import UIKit
// import PlaygroundSupport
import AVFoundation

let synthesizer = AVSpeechSynthesizer() 

class ViewController: UIViewController {
    
    var screenWidth: CGFloat = 0
    var screenHeight: CGFloat = 0
    
    // 四角のサイズ
    var figSize: CGFloat = 40.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //画面のサイズ
        screenWidth = self.view.bounds.width
        screenHeight = self.view.bounds.height - figSize
        
        //画像表示作成
        let rect = UIImageView(frame: CGRect(x: screenWidth/2, y: screenHeight/2, width: figSize, height: figSize))
        rect.image = UIImage(named: "skisss1")
        self.view.addSubview(rect)
        
        // タイマーで画像を動かす
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: {
            timer in
            self.move(figure: rect)
        })
        
    }
    
    func move(figure: UIView) {
        figure.center.x = figure.center.x + 1
    }
    
    func isXOnScreen(figure: UIView) -> Bool {
        if figure.center.x > 0 && figure.center.x < screenWidth {
            return false
        } else {
            return true
        }
    }
    
    func isYOnScreen(figure: UIView) -> Bool {
        if figure.center.y > 0 && figure.center.y < screenHeight {
            return false
        } else {
            return true
        }
    }
    
    /**
     引数で渡されたtext:Stringを音声出力する
     - parameter text: 音声出力するテキスト
     */
    func speak(_ text: String) {
        /* let synthesizer = AVSpeechSynthesizer() */
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "ja-JP")
        synthesizer.speak(utterance)
    }
}

