import AVFoundation

// iPadOS16の場合、ここに持ってくる
let synthesizer = AVSpeechSynthesizer()

/**
 引数で渡されたtext:Stringを音声出力する
 - parameter text: 音声出力するテキスト
 */
func speak(_ text: String) {
    // iPadOS16ではここを関数の外に出す
    // let synthesizer = AVSpeechSynthesizer()
    let utterance = AVSpeechUtterance(string: text)
    utterance.voice = AVSpeechSynthesisVoice(language: "ja-JP")
    synthesizer.speak(utterance)
}
