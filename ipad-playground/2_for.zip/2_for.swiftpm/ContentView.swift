import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Button(action:{
                for count in 1...3 {
                    speak(String(count) + "年生")
                }
            }) {
                Image(systemName: "speaker")
            }
        }
    }
}
