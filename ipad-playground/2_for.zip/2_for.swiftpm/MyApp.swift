import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

/*
 Image("イメージアセット").resizable()
 .frame(width: 100, height: 100)
 */
