import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Button(action:{
                for count in 1...3 {
                    if (count == 1) {
                        speak(String(count) + "年生の皆さん")
                    } else {
                        speak(String(count) + "年生")
                    }
                }
            }) {
                Image(systemName: "mic")
                    .resizable().scaledToFit()
                    .frame(width:200, height:200)
            }
        }
    }
}
